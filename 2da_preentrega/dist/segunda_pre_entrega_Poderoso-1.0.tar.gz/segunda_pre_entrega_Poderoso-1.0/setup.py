from setuptools import setup

setup(


name='segunda_pre_entrega_Poderoso',
version= '1.0',
description='paquete pre entrega 2',
autor='Poderos Francisco',
autor_email='franpoderoso@hotmail.com',

pckage=['paquetes']
)